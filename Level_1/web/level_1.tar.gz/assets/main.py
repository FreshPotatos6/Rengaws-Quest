import pygame
import asyncio
import random

# --- 1. INITIALIZATION ---
pygame.init()
pygame.mixer.pre_init(44100, -16, 2, 512) 
pygame.mixer.init() 

WIDTH, HEIGHT = 800, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Level 4: Ice Slide")
clock = pygame.time.Clock()

# --- 2. FONTS (Defined early to prevent NameError) ---
font = pygame.font.SysFont("Arial", 22, bold=True)
title_font = pygame.font.SysFont("Courier New", 32, bold=True)
desc_font = pygame.font.SysFont("Arial", 18, italic=True)

# --- 3. MUSIC & SOUND ---
try:
    pygame.mixer.music.load("Zelda.ogg") 
    pygame.mixer.music.set_volume(0.5) 
    pygame.mixer.music.play(-1) 
    victory_sound = pygame.mixer.Sound("Zelda.wav")
except Exception as e:
    print(f"Audio Error: {e}")
    victory_sound = pygame.mixer.Sound(buffer=bytes(100))

# --- 4. ASSET LOADERS ---
TS = 85 
def load_art(name, fallback_color, size=(TS, TS)):
    try:
        return pygame.transform.scale(pygame.image.load(name).convert_alpha(), size)
    except:
        s = pygame.Surface(size, pygame.SRCALPHA); s.fill(fallback_color); return s

img_bg     = load_art("background.png", (220, 240, 255), (WIDTH, HEIGHT))
img_block  = load_art("Rock.png", (139, 69, 19))
img_switch = load_art("Switch.png", (255, 100, 100))
img_ice    = load_art("Ice.png", (170, 210, 255))
img_snow   = load_art("Snow.png", (255, 255, 255))

P_SIZE = 140
player_sprites = {
    "up":    load_art("player_up.png", (255, 200, 0), (P_SIZE, P_SIZE)),
    "down":  load_art("player_down.png", (220, 180, 0), (P_SIZE, P_SIZE)),
    "left":  load_art("player_left.png", (200, 160, 0), (P_SIZE, P_SIZE)),
    "right": load_art("player_right.png", (180, 140, 0), (P_SIZE, P_SIZE))
}

# --- 5. GAME OBJECTS & STATE ---
L1_MAP = ["ssssss", "ssiiXs", "sXOiis", "siiOis", "siiXOs", "ssssss"]
OX, OY = (WIDTH - (len(L1_MAP[0])*TS)) // 2, 85

blocks = []
switches = []
physics_rect = pygame.Rect(0, 0, 20, 10) 
current_facing = "down"
victory_sound_played = False
victory_timer = 0  
confetti_particles = []

class Confetti:
    def __init__(self):
        self.x = WIDTH // 2
        self.y = HEIGHT // 2
        self.color = random.choice([(255,50,50), (50,255,50), (255,255,50), (50,255,255), (255,50,255)])
        self.size = random.randint(6, 12)
        self.vx = random.uniform(-12, 12)
        self.vy = random.uniform(-18, 2)
        self.gravity = 0.35

    def update(self):
        self.x += self.vx
        self.y += self.vy
        self.vy += self.gravity

    def draw(self, surface):
        pygame.draw.rect(surface, self.color, (self.x, self.y, self.size, self.size))

def init_level():
    global blocks, switches, physics_rect, victory_sound_played, current_facing, victory_timer, confetti_particles
    victory_sound_played = False
    victory_timer = 0
    confetti_particles = []
    current_facing = "down"
    blocks = []
    switches = []
    physics_rect.center = (WIDTH // 2, OY + (5 * TS) + 40)
    for r, row in enumerate(L1_MAP):
        for c, char in enumerate(row):
            rect = pygame.Rect(OX + c*TS, OY + r*TS, TS, TS)
            if char == "X": blocks.append({"rect": rect.copy(), "sliding": False, "dir": [0,0]})
            if char == "O": switches.append(rect)

init_level()

ctrls = {
    "up": (pygame.Rect(120, 380, 80, 80), ""), "down": (pygame.Rect(120, 500, 80, 80), ""),
    "left": (pygame.Rect(40, 440, 80, 80), ""), "right": (pygame.Rect(200, 440, 80, 80), ""),
    "reset": (pygame.Rect(640, 20, 140, 60), "RESET")
}

# --- 6. MAIN LOOP ---
async def main():
    global current_facing, victory_sound_played, victory_timer
    while True:
        screen.blit(img_bg, (0, 0))
        m_pos, m_down = pygame.mouse.get_pos(), pygame.mouse.get_pressed()[0]
        clue = None
        
        for event in pygame.event.get():
            if event.type == pygame.QUIT: return
            if event.type == pygame.MOUSEBUTTONDOWN and ctrls["reset"][0].collidepoint(event.pos):
                init_level()

        dx = dy = 0
        if m_down:
            if ctrls["up"][0].collidepoint(m_pos): dy = -5; current_facing = "up"
            elif ctrls["down"][0].collidepoint(m_pos): dy = 5; current_facing = "down"
            elif ctrls["left"][0].collidepoint(m_pos): dx = -5; current_facing = "left"
            elif ctrls["right"][0].collidepoint(m_pos): dx = 5; current_facing = "right"
        
        if dx != 0 or dy != 0:
            next_phys = physics_rect.move(dx, dy)
            grid_x, grid_y = (next_phys.centerx - OX)//TS, (next_phys.centery - OY)//TS
            if 0 <= grid_y < len(L1_MAP) and 0 <= grid_x < len(L1_MAP[0]):
                can_move = True
                for b in blocks:
                    if next_phys.colliderect(b["rect"]):
                        if not b["sliding"]:
                            b["sliding"] = True
                            b["dir"] = [1,0] if dx>0 else [-1,0] if dx<0 else [0,1] if dy>0 else [0,-1]
                        can_move = False
                if can_move: physics_rect.topleft = next_phys.topleft

        # Draw World Tiles
        on_sw = 0
        for r, row in enumerate(L1_MAP):
            for c, char in enumerate(row):
                rect = pygame.Rect(OX+c*TS, OY+r*TS, TS, TS)
                screen.blit(img_snow if char == "s" else img_ice, rect)
                if char == "O": screen.blit(img_switch, rect)
        
        # Block Logic
        for i, b in enumerate(blocks):
            if b["sliding"]:
                nb = b["rect"].copy()
                nb.x += b["dir"][0]*12; nb.y += b["dir"][1]*12
                gc, gr = (nb.centerx-OX)//TS, (nb.centery-OY)//TS
                stop = not (0<=gr<len(L1_MAP) and 0<=gc<len(L1_MAP[0])) or L1_MAP[gr][gc]=="s"
                if not stop:
                    for j, other in enumerate(blocks):
                        if i != j and nb.colliderect(other["rect"]): stop = True
                if stop:
                    b["sliding"] = False
                    grid_c, grid_r = (b["rect"].centerx - OX) // TS, (b["rect"].centery - OY) // TS
                    b["rect"].topleft = (OX + grid_c * TS, OY + grid_r * TS)
                else: b["rect"].topleft = nb.topleft
            screen.blit(img_block, b["rect"])
            if any(b["rect"].colliderect(s) for s in switches): on_sw += 1
        
        # Victory Logic
        if on_sw == 3:
            victory_timer += 1
            if victory_timer > 15: # ~0.25 seconds
                clue = "Its Dangerous to go alone! Check your favorite board game"
                if not victory_sound_played:
                    victory_sound.play() 
                    victory_sound_played = True
                    for _ in range(60): confetti_particles.append(Confetti())
        else:
            victory_timer = 0 

        for p in confetti_particles:
            p.update(); p.draw(screen)

        # Draw Player
        screen.blit(player_sprites[current_facing], (physics_rect.centerx - (P_SIZE // 2), physics_rect.bottom - (P_SIZE - 5)))

        # Header UI
        header_rect = pygame.Rect(WIDTH//2 - 250, 10, 500, 80)
        pygame.draw.rect(screen, (255, 255, 255, 180), header_rect, border_radius=15)
        screen.blit(title_font.render("The Legend of Rengaw", True, (0,0,0)), (WIDTH//2-200, 15))
        screen.blit(desc_font.render("Hit the 3 Switches", True, (50,50,50)), (WIDTH//2-140, 55))

        # Control UI
        ui_overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        for n, (r, label) in ctrls.items():
            color = (200, 50, 50, 140) if n == "reset" else (40, 40, 40, 120)
            pygame.draw.rect(ui_overlay, color, r, border_radius=12)
            lbl = font.render(label, True, (255,255,255))
            ui_overlay.blit(lbl, lbl.get_rect(center=r.center))
        screen.blit(ui_overlay, (0,0))
        
        if clue:
            txt = font.render(clue, True, (200, 0, 0))
            screen.blit(txt, txt.get_rect(center=(WIDTH//2, 560)))

        pygame.display.flip(); await asyncio.sleep(0); clock.tick(60)

if __name__ == "__main__": asyncio.run(main())