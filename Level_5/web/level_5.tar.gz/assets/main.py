import pygame
import asyncio
import random
import math

# --- 1. INITIALIZATION ---
pygame.init()
pygame.mixer.pre_init(44100, -16, 2, 512)
pygame.mixer.init()

WIDTH, HEIGHT = 800, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Level 5: RengawBound")
clock = pygame.time.Clock()

# Fonts
font = pygame.font.SysFont("Arial", 22, bold=True)
hp_font = pygame.font.SysFont("Courier New", 36, bold=True) 
title_font = pygame.font.SysFont("Courier New", 32, bold=True)
desc_font = pygame.font.SysFont("Arial", 18, italic=True)

# --- 2. MUSIC & SOUND ---
try:
    pygame.mixer.music.load("Earth.ogg") 
    pygame.mixer.music.set_volume(0.4)
    pygame.mixer.music.play(-1)
    
    pk_fire_snd = pygame.mixer.Sound("PKfire.ogg") 
    victory_snd = pygame.mixer.Sound("Victory.ogg") 
except Exception as e:
    print(f"Audio Placeholder: {e}")

# --- 3. GLOBAL STATE ---
ui_surface = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
# CHARACTER SIZE INCREASED TO 80x80
player_rect = pygame.Rect(400, 350, 80, 80) 
target_hp = 500.0
display_hp = 500.0
roll_speed = 0.4 
butterflies_saved = 0
level_cleared = False
victory_sound_played = False
waiting_to_start = True 
current_facing = "down"

starmen = []
butterflies = []
floating_texts = []
fire_effects = []

# --- 4. ASSETS ---
def load_img(name, color, size=(80, 80)):
    try: return pygame.transform.scale(pygame.image.load(name).convert_alpha(), size)
    except: 
        s = pygame.Surface(size, pygame.SRCALPHA); s.fill(color); return s

player_sprites = {
    "up":    load_img("Earth_up.png", (255, 0, 0)),
    "down":  load_img("Earth_down.png", (200, 0, 0)),
    "left":  load_img("Earth_left.png", (150, 0, 0)),
    "right": load_img("Earth_right.png", (100, 0, 0))
}

img_star = load_img("Starman.png", (200, 200, 200), (80, 110))
img_bfly = load_img("Butterfly.png", (255, 100, 255), (35, 35))
img_fire_ring = load_img("Fire.png", (255, 69, 0), (140, 140))

# --- 5. HELPERS ---
def draw_eb_background(t):
    for y in range(0, HEIGHT, 8):
        wave1 = 30 * math.sin(y * 0.008 + t * 0.05)
        wave2 = 15 * math.sin(y * 0.02 - t * 0.03)
        offset = wave1 + wave2
        
        r = int(127 + 127 * math.sin(t * 0.02 + y * 0.005))
        g = int(127 + 127 * math.sin(t * 0.03 + y * 0.01))
        b = int(127 + 127 * math.sin(t * 0.01 + y * 0.002))
        
        pygame.draw.rect(screen, (r // 4, g // 8, b // 2), (0, y, WIDTH, 8))
        line_color = (r // 2, g // 2, b)
        pygame.draw.line(screen, line_color, (offset, y), (WIDTH + offset, y), 2)

def spawn_text(txt, pos, color=(255, 255, 255)):
    floating_texts.append({"txt": txt, "pos": list(pos), "timer": 45, "color": color})

def draw_arrow(surface, rect, direction):
    center, s = rect.center, 15
    if direction == "up": pts = [(center[0], center[1]-s), (center[0]-s, center[1]+s), (center[0]+s, center[1]+s)]
    elif direction == "down": pts = [(center[0], center[1]+s), (center[0]-s, center[1]-s), (center[0]+s, center[1]-s)]
    elif direction == "left": pts = [(center[0]-s, center[1]), (center[0]+s, center[1]-s), (center[0]+s, center[1]+s)]
    elif direction == "right": pts = [(center[0]+s, center[1]), (center[0]-s, center[1]-s), (center[0]-s, center[1]+s)]
    pygame.draw.polygon(surface, (255,255,255), pts)

def init_level():
    global starmen, butterflies, target_hp, display_hp, butterflies_saved, level_cleared, player_rect, waiting_to_start, current_facing, victory_sound_played
    target_hp, display_hp = 500.0, 500.0
    butterflies_saved = 0
    level_cleared = False
    victory_sound_played = False
    waiting_to_start = True 
    current_facing = "down"
    player_rect.center = (400, 350)
    starmen = [{"rect": pygame.Rect(random.choice([50, 750]), random.randint(150, 550), 80, 110), "speed": random.uniform(1.8, 2.5)} for _ in range(3)]
    butterflies = [pygame.Rect(100, 200, 35, 35), pygame.Rect(700, 200, 35, 35), pygame.Rect(400, 530, 35, 35)]

init_level()

bs = 75
ctrls = {
    "up": pygame.Rect(120, 380, bs, bs), "down": pygame.Rect(120, 500, bs, bs), 
    "left": pygame.Rect(40, 440, bs, bs), "right": pygame.Rect(200, 440, bs, bs), 
    "action": pygame.Rect(640, 20, 140, 60) 
}

# --- 6. MAIN LOOP ---
async def main():
    global target_hp, display_hp, butterflies_saved, level_cleared, waiting_to_start, current_facing, victory_sound_played
    ticks = 0
    
    while True:
        draw_eb_background(ticks)
        ticks += 1
        
        m_pos, m_down = pygame.mouse.get_pos(), pygame.mouse.get_pressed()[0]
        action_triggered = False

        for event in pygame.event.get():
            if event.type == pygame.QUIT: return
            if event.type == pygame.MOUSEBUTTONDOWN and ctrls["action"].collidepoint(event.pos):
                action_triggered = True
                waiting_to_start = False

        if not level_cleared:
            dx, dy = 0, 0
            if m_down:
                waiting_to_start = False
                if ctrls["up"].collidepoint(m_pos): dy = -6; current_facing = "up"
                elif ctrls["down"].collidepoint(m_pos): dy = 6; current_facing = "down"
                elif ctrls["left"].collidepoint(m_pos): dx = -6; current_facing = "left"
                elif ctrls["right"].collidepoint(m_pos): dx = 6; current_facing = "right"
            
            if not waiting_to_start:
                target_hp -= roll_speed 
                diff = abs(display_hp - target_hp)
                if diff > 0.1:
                    step = max(0.4, diff * 0.1) 
                    if display_hp > target_hp: display_hp -= step
                    else: display_hp += step

                if display_hp <= 0: init_level() 

                player_rect.x = max(0, min(WIDTH-80, player_rect.x + dx))
                player_rect.y = max(110, min(HEIGHT-80, player_rect.y + dy))

                if action_triggered:
                    blast_radius = 160
                    fire_effects.append({"pos": player_rect.center, "radius": 10, "max_radius": blast_radius, "timer": 15})
                    spawn_text("PK FIRE!!", player_rect.topleft, (255, 150, 0))
                    try: pk_fire_snd.play()
                    except: pass
                    for s in starmen[:]:
                        dist = pygame.math.Vector2(player_rect.center).distance_to(s["rect"].center)
                        if dist < blast_radius:
                            starmen.remove(s)
                            # HP RECOVERY INCREASED TO 85
                            target_hp += 85.0 
                            starmen.append({"rect": pygame.Rect(random.choice([-150, 950]), random.randint(150, 600), 80, 110), "speed": random.uniform(2.0, 3.0)})

                for s in starmen:
                    if s["rect"].x < player_rect.x: s["rect"].x += s["speed"]
                    else: s["rect"].x -= s["speed"]
                    if s["rect"].y < player_rect.y: s["rect"].y += s["speed"]
                    else: s["rect"].y -= s["speed"]
                    if player_rect.colliderect(s["rect"]):
                        target_hp -= 10.0 

                for b in butterflies[:]:
                    if player_rect.colliderect(b):
                        butterflies.remove(b)
                        butterflies_saved += 1
                        target_hp = min(500, target_hp + 150) 
                        if butterflies_saved >= 3: level_cleared = True

        # --- DRAWING ENTITIES ---
        for b in butterflies: screen.blit(img_bfly, b)
        for s in starmen: screen.blit(img_star, s["rect"])
        
        for f in fire_effects[:]:
            current_size = int(f["radius"] * 2.6)
            scaled_fire = pygame.transform.scale(img_fire_ring, (current_size, current_size))
            fire_rect = scaled_fire.get_rect(center=f["pos"])
            screen.blit(scaled_fire, fire_rect)
            f["radius"] += 12; f["timer"] -= 1
            if f["timer"] <= 0: fire_effects.remove(f)
        
        screen.blit(player_sprites[current_facing], player_rect.topleft)

        # UI Styling...
        t_surf = title_font.render("Level 5: RengawBound", True, (0, 0, 0))
        box_width = max(350, t_surf.get_width() + 40)
        header_rect = pygame.Rect(WIDTH//2 - box_width//2, 10, box_width, 85)
        pygame.draw.rect(screen, (255, 255, 255, 190), header_rect, border_radius=15)
        screen.blit(t_surf, t_surf.get_rect(center=(WIDTH//2, 35)))
        
        goal_txt = f"Collect Butterflies: {butterflies_saved}/3"
        goal_surf = desc_font.render(goal_txt, True, (200, 0, 200))
        screen.blit(goal_surf, goal_surf.get_rect(center=(WIDTH//2, 65)))

        hp_box_rect = pygame.Rect(WIDTH//2 - 60, 105, 120, 50)
        pygame.draw.rect(screen, (0, 0, 0), hp_box_rect)
        border_col = (0, 255, 0) if display_hp > 100 else (255, 0, 0)
        pygame.draw.rect(screen, border_col, hp_box_rect, 3)
        hp_val = max(0, int(display_hp))
        hp_surf = hp_font.render(f"{hp_val:03}", True, border_col)
        screen.blit(hp_surf, hp_surf.get_rect(center=hp_box_rect.center))

        for ft in floating_texts[:]:
            screen.blit(font.render(ft["txt"], True, ft["color"]), ft["pos"])
            ft["pos"][1] -= 2; ft["timer"] -= 1
            if ft["timer"] <= 0: floating_texts.remove(ft)

        if level_cleared:
            if not victory_sound_played:
                try: victory_snd.play()
                except: pass
                victory_sound_played = True
            win_txt = title_font.render("HAPPY BIRTHDAY! Your gift awaits!", True, (255, 255, 0))
            screen.blit(win_txt, win_txt.get_rect(center=(WIDTH//2, HEIGHT//2 + 50)))

        ui_surface.fill((0,0,0,0))
        for n, r in ctrls.items():
            pygame.draw.rect(ui_surface, (40, 40, 40, 130), r, border_radius=12)
            if n == "action": 
                txt = font.render("PK FIRE", True, (255,255,255))
                ui_surface.blit(txt, txt.get_rect(center=r.center))
            else: draw_arrow(ui_surface, r, n)
        screen.blit(ui_surface, (0,0))

        pygame.display.flip()
        await asyncio.sleep(0)
        clock.tick(60)

if __name__ == "__main__":
    asyncio.run(main())