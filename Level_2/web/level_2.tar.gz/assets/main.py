import pygame
import asyncio
import random

# --- 1. INITIALIZATION ---
pygame.init()
pygame.mixer.pre_init(44100, -16, 2, 512) 
pygame.mixer.init() 

WIDTH, HEIGHT = 800, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Level 2: Rengaw's Mansion")
clock = pygame.time.Clock()

# --- 2. FONTS ---
font = pygame.font.SysFont("Arial", 22, bold=True)
title_font = pygame.font.SysFont("Courier New", 32, bold=True)
desc_font = pygame.font.SysFont("Arial", 18, italic=True)

# --- 3. MUSIC & SOUND SECTION ---
try:
    # Ensure these filenames match your folder exactly!
    pygame.mixer.music.load("Luigi.ogg") 
    pygame.mixer.music.set_volume(0.4) 
    pygame.mixer.music.play(-1) # <--- BACK ON: -1 means loop forever
    
    victory_sound = pygame.mixer.Sound("Luigi.wav") 
except Exception as e:
    print(f"Audio Error: {e}")
    victory_sound = pygame.mixer.Sound(buffer=bytes(100))

# --- 4. ASSET LOADERS ---
L2_TS = 38 
def load_art(name, fallback_color, size):
    try:
        return pygame.transform.scale(pygame.image.load(name).convert_alpha(), size)
    except:
        s = pygame.Surface(size, pygame.SRCALPHA); s.fill(fallback_color); return s

img_ghost  = load_art("Ghost.png", (200, 200, 255, 180), (80, 80))
img_wall   = load_art("Wall.png", (40, 40, 60), (L2_TS, L2_TS))

P_VISUAL_SIZE = 80 
player_sprites = {
    "up":    load_art("Luigi_up.png", (0, 255, 0), (P_VISUAL_SIZE, P_VISUAL_SIZE)),
    "down":  load_art("Luigi_down.png", (0, 200, 0), (P_VISUAL_SIZE, P_VISUAL_SIZE)),
    "left":  load_art("Luigi_left.png", (0, 150, 0), (P_VISUAL_SIZE, P_VISUAL_SIZE)),
    "right": load_art("Luigi_right.png", (0, 100, 0), (P_VISUAL_SIZE, P_VISUAL_SIZE))
}

# --- 5. GAME OBJECTS & CONFETTI ---
class Confetti:
    def __init__(self):
        self.x, self.y = WIDTH // 2, HEIGHT // 2
        # Rainbow colors for a big celebration
        self.color = random.choice([(255,50,50), (50,255,50), (255,255,50), (50,255,255), (255,50,255)])
        self.size = random.randint(6, 12)
        self.vx, self.vy = random.uniform(-12, 12), random.uniform(-18, 2)
        self.gravity = 0.35
    def update(self): self.x += self.vx; self.y += self.vy; self.vy += self.gravity
    def draw(self, surf): pygame.draw.rect(surf, self.color, (self.x, self.y, self.size, self.size))

L2_MAP = [
    "MMMMMMMMMMMMMMMMMMMM",
    "M.........M........M",
    "M.MMMMMMM.M.MMMMMM.M",
    "M.M....G..M.M...G..M",
    "M.M.MMMMMMM.M.MMMM.M",
    "M.M.M.......M....M.M",
    "M.M.M.MMMMMMMMMM.M.M",
    "M.M.M............M.M",
    "M.M.MMMMMMMMMMMMMM.M",
    "M.M.......M........M",
    "M.MMMMMMM.M.MMMMMM.M",
    "M.......M.M.M......M",
    "MMMMMMM.M.M.M.MMMMMM",
    "M....G..M...M......M",
    "MMMMMMMMMMMMMMMMMMMM"
]

l2_walls, l2_ghosts = [], []
# Hitbox centered at the bottom (the feet)
player_rect = pygame.Rect(65, 85, 20, 12) 
current_facing = "down"
victory_timer = 0
victory_sound_played = False
confetti_particles = []
hint_timer = 0

def init_level():
    global l2_walls, l2_ghosts, player_rect, victory_sound_played, hint_timer, victory_timer, confetti_particles
    victory_sound_played = False
    victory_timer = 0
    confetti_particles = []
    hint_timer = 0
    l2_walls, l2_ghosts = [], []
    player_rect.topleft = (65, 85)
    for r, row in enumerate(L2_MAP):
        for c, char in enumerate(row):
            rect = pygame.Rect(c*L2_TS + 20, r*L2_TS + 40, L2_TS, L2_TS)
            if char == "M": l2_walls.append(rect)
            elif char == "G": l2_ghosts.append({"rect": rect, "found": False})

init_level()

ctrls = {"up": (pygame.Rect(120, 380, 80, 80), ""), "down": (pygame.Rect(120, 500, 80, 80), ""),
         "left": (pygame.Rect(40, 440, 80, 80), ""), "right": (pygame.Rect(200, 440, 80, 80), ""),
         "hint": (pygame.Rect(680, 20, 100, 50), "HINT")}

# --- 6. MAIN LOOP ---
async def main():
    global hint_timer, victory_sound_played, victory_timer, current_facing
    while True:
        screen.fill((5, 5, 15))
        m_pos, m_down = pygame.mouse.get_pos(), pygame.mouse.get_pressed()[0]
        clue = None
        
        for event in pygame.event.get():
            if event.type == pygame.QUIT: return
            if event.type == pygame.MOUSEBUTTONDOWN and ctrls["hint"][0].collidepoint(event.pos):
                hint_timer = 60

        # --- MOVEMENT ---
        dx = dy = 0
        if m_down:
            if ctrls["up"][0].collidepoint(m_pos): dy = -6; current_facing = "up"
            elif ctrls["down"][0].collidepoint(m_pos): dy = 6; current_facing = "down"
            elif ctrls["left"][0].collidepoint(m_pos): dx = -6; current_facing = "left"
            elif ctrls["right"][0].collidepoint(m_pos): dx = 6; current_facing = "right"
        
        if dx != 0:
            tr = player_rect.move(dx, 0)
            if not any(tr.colliderect(w) for w in l2_walls): player_rect.x += dx
        if dy != 0:
            tr = player_rect.move(0, dy)
            if not any(tr.colliderect(w) for w in l2_walls): player_rect.y += dy

        found_count = 0
        target_hint = None
        for g in l2_ghosts:
            if player_rect.colliderect(g["rect"]): g["found"] = True
            if g["found"]: found_count += 1
            elif target_hint is None: target_hint = g

        # --- DRAW WORLD ---
        for w in l2_walls: screen.blit(img_wall, w)
        
        # Fog Layer
        fog = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        fog.fill((0, 0, 0, 245)) 
        pygame.draw.circle(fog, (0, 0, 0, 0), player_rect.center, 60) 
        screen.blit(fog, (0, 0))
        
        # Found ghosts drawn after fog to stay visible
        for g in l2_ghosts:
            if g["found"]: screen.blit(img_ghost, g["rect"])
        
        if hint_timer > 0 and target_hint:
            pygame.draw.circle(screen, (255, 255, 0), target_hint["rect"].center, 30, 4)
            hint_timer -= 1
        
        # --- PLAYER DRAWING (FEET ALIGNED) ---
        draw_x = player_rect.centerx - (P_VISUAL_SIZE // 2)
        draw_y = player_rect.bottom - P_VISUAL_SIZE + 5 
        screen.blit(player_sprites[current_facing], (draw_x, draw_y))

        # --- VICTORY LOGIC ---
        if found_count == 3:
            victory_timer += 1
            if victory_timer > 15: # 0.25s settle time
                clue = "You got the ghosts! check the console you originally found the ghosts on"
                if not victory_sound_played:
                    victory_sound.play() 
                    victory_sound_played = True
                    for _ in range(60): confetti_particles.append(Confetti())
        
        for p in confetti_particles: p.update(); p.draw(screen)

        # --- HEADER UI ---
        header_rect = pygame.Rect(WIDTH//2 - 250, 10, 500, 80)
        pygame.draw.rect(screen, (255, 255, 255, 180), header_rect, border_radius=15)
        screen.blit(title_font.render("Rengaw Valley Maze", True, (0,0,0)), (WIDTH//2-180, 15))
        counter_text = f"Find the 3 ghosts! ({found_count}/3)"
        screen.blit(desc_font.render(counter_text, True, (50,50,50)), (WIDTH//2-120, 55))

        # --- CONTROL UI ---
        ui_overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        for name, (rect, label) in ctrls.items():
            btn_alpha = 130 if name == "hint" else 90
            pygame.draw.rect(ui_overlay, (200, 200, 200, btn_alpha), rect, border_radius=15)
            txt = font.render(label, True, (255, 255, 255))
            ui_overlay.blit(txt, txt.get_rect(center=rect.center))
        screen.blit(ui_overlay, (0,0))
            
        if clue:
            c_surf = font.render(clue, True, (0, 255, 100))
            screen.blit(c_surf, c_surf.get_rect(center=(WIDTH//2, 570)))

        pygame.display.flip(); await asyncio.sleep(0); clock.tick(60)

if __name__ == "__main__": asyncio.run(main())