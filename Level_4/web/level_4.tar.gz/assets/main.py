import pygame
import asyncio
import random

# --- 1. INITIALIZATION ---
pygame.init()
pygame.mixer.pre_init(44100, -16, 2, 512)
pygame.mixer.init()

WIDTH, HEIGHT = 800, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Level 4: Rengaw Valley")
clock = pygame.time.Clock()

font = pygame.font.SysFont("Arial", 22, bold=True)
title_font = pygame.font.SysFont("Courier New", 32, bold=True)
desc_font = pygame.font.SysFont("Arial", 18, italic=True)

# --- 2. MUSIC & SOUND ---
try:
    pygame.mixer.music.load("Valley.ogg") 
    pygame.mixer.music.set_volume(0.3)
    pygame.mixer.music.play(-1)
    victory_sparkle = pygame.mixer.Sound("Luigi.ogg") 
except Exception as e:
    print(f"Audio Placeholder: {e}")

# --- 3. GLOBAL STATE ---
ui_surface = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
# Visual Rect (100x100)
player_rect = pygame.Rect(50, 150, 100, 100) 
# Physics Rect (Footbox: 50x30 centered at the bottom of the player)
foot_rect = pygame.Rect(0, 0, 50, 30)

confetti_particles = []
floating_texts = []
level_cleared = False
PLAYER_SPEED = 6
current_facing = "down" 
last_dx, last_dy = 0, 1 

has_hammer = has_scythe = has_pole = False
keys_found = 0
rock_key_id, weed_key_id, water_key_id = 4, 2, 3
rock_key_claimed = weed_key_claimed = water_key_claimed = False

rocks, weeds, water_tiles = [], [], []
items_on_ground = {}

# --- 4. ASSETS ---
def load_img(name, color, size=(50, 50)):
    try: return pygame.transform.scale(pygame.image.load(name).convert_alpha(), size)
    except: 
        s = pygame.Surface(size, pygame.SRCALPHA); s.fill(color); return s

grass_tile_size = 64
img_grass_tile = load_img("Grass.png", (70, 130, 60), (grass_tile_size, grass_tile_size))
img_water_tex = load_img("Water.png", (40, 110, 220), (60, 60))

psize = (100, 100)
player_sprites = {
    "up":    load_img("Valley_up.png", (255, 215, 0), psize),
    "down":  load_img("Valley_down.png", (255, 200, 0), psize),
    "left":  load_img("Valley_left.png", (255, 180, 0), psize),
    "right": load_img("Valley_right.png", (255, 160, 0), psize)
}

img_rock = load_img("Rock.png", (80, 80, 80), (80, 80))
img_weed = load_img("Weed.png", (34, 139, 34), (35, 35)) 
img_ham = load_img("Hammer.png", (200, 200, 200), (90, 90))
img_scy = load_img("Scythe.png", (50, 220, 50), (70, 70))
img_pole = load_img("Fish.png", (160, 100, 50), (90, 90))

# --- 5. HELPERS ---
def update_footbox():
    """ Keeps the small physics box centered at the bottom of the large sprite """
    foot_rect.midbottom = player_rect.midbottom

def spawn_text(txt, pos, color=(255, 255, 255), offset_y=0):
    floating_texts.append({"txt": txt, "pos": [pos[0], pos[1] + offset_y], "timer": 90, "color": color})

def draw_arrow(surface, rect, direction):
    center, s = rect.center, 15
    if direction == "up": pts = [(center[0], center[1]-s), (center[0]-s, center[1]+s), (center[0]+s, center[1]+s)]
    elif direction == "down": pts = [(center[0], center[1]+s), (center[0]-s, center[1]-s), (center[0]+s, center[1]-s)]
    elif direction == "left": pts = [(center[0]-s, center[1]), (center[0]+s, center[1]-s), (center[0]+s, center[1]+s)]
    elif direction == "right": pts = [(center[0]+s, center[1]), (center[0]-s, center[1]-s), (center[0]-s, center[1]+s)]
    pygame.draw.polygon(surface, (255,255,255), pts)

def draw_grass_grid():
    for x in range(0, WIDTH, grass_tile_size):
        for y in range(0, HEIGHT, grass_tile_size):
            screen.blit(img_grass_tile, (x, y))

def init_level():
    global rocks, weeds, water_tiles, player_rect, level_cleared, items_on_ground
    global has_hammer, has_scythe, has_pole, keys_found, rock_key_claimed, weed_key_claimed, water_key_claimed
    level_cleared = False
    confetti_particles.clear(); floating_texts.clear()
    keys_found = 0
    has_hammer = has_scythe = has_pole = False
    rock_key_claimed = weed_key_claimed = water_key_claimed = False
    player_rect.topleft = (50, 180)
    update_footbox()
    
    rocks[:] = [{"rect": pygame.Rect(250 + (i % 3) * 140 + 10, 180 + (i // 3) * 110 + 10, 60, 60), "draw_pos": (250 + (i % 3) * 140, 180 + (i // 3) * 110), "id": i} for i in range(9)]
    weeds[:] = [{"rect": pygame.Rect(100 + (i % 4) * 120, 440 + (i // 4) * 60, 35, 35), "id": i} for i in range(8)]
    water_tiles[:] = [{"rect": pygame.Rect(720, 100 + (i*60), 60, 60), "id": i} for i in range(8)]
    
    items_on_ground = {
        "hammer": pygame.Rect(30, 500, 90, 90), 
        "scythe": pygame.Rect(450, 150, 70, 70), 
        "fishing pole": pygame.Rect(650, 480, 90, 90)
    }

init_level()

bs = 75
ctrls = {
    "up": pygame.Rect(120, 380, bs, bs), "down": pygame.Rect(120, 500, bs, bs), 
    "left": pygame.Rect(40, 440, bs, bs), "right": pygame.Rect(200, 440, bs, bs), 
    "action": pygame.Rect(640, 20, 140, 60)
}

# --- 6. MAIN LOOP ---
async def main():
    global keys_found, last_dx, last_dy, current_facing, player_rect, level_cleared
    global has_hammer, has_scythe, has_pole
    global rock_key_claimed, weed_key_claimed, water_key_claimed
    
    while True:
        dx, dy, action_triggered = 0, 0, False
        m_pos, m_down = pygame.mouse.get_pos(), pygame.mouse.get_pressed()[0]
        
        draw_grass_grid()

        for event in pygame.event.get():
            if event.type == pygame.QUIT: return
            if event.type == pygame.MOUSEBUTTONDOWN and ctrls["action"].collidepoint(event.pos):
                action_triggered = True

        if m_down:
            if ctrls["up"].collidepoint(m_pos): dy = -PLAYER_SPEED; current_facing = "up"; last_dx, last_dy = 0, -1
            elif ctrls["down"].collidepoint(m_pos): dy = PLAYER_SPEED; current_facing = "down"; last_dx, last_dy = 0, 1
            elif ctrls["left"].collidepoint(m_pos): dx = -PLAYER_SPEED; current_facing = "left"; last_dx, last_dy = -1, 0
            elif ctrls["right"].collidepoint(m_pos): dx = PLAYER_SPEED; current_facing = "right"; last_dx, last_dy = 1, 0

        # Collision & Movement using FOOTBOX
        if dx != 0:
            nf = foot_rect.move(dx, 0)
            if 0 <= nf.left and nf.right <= WIDTH and not any(nf.colliderect(r["rect"]) for r in rocks) and not any(nf.colliderect(w["rect"]) for w in water_tiles):
                player_rect.x += dx
                update_footbox()
        if dy != 0:
            nf = foot_rect.move(0, dy)
            if 100 <= nf.top and nf.bottom <= HEIGHT and not any(nf.colliderect(r["rect"]) for r in rocks) and not any(nf.colliderect(w["rect"]) for w in water_tiles):
                player_rect.y += dy
                update_footbox()

        # Item Pickup
        for tool in list(items_on_ground.keys()):
            if foot_rect.colliderect(items_on_ground[tool]):
                if tool == "hammer": has_hammer = True
                elif tool == "scythe": has_scythe = True
                elif tool == "fishing pole": has_pole = True
                del items_on_ground[tool]
                spawn_text(f"Got {tool.title()}!", player_rect.topleft, (255, 255, 0))

        # ACTION LOGIC - Origins from the FEET
        if action_triggered:
            # We cast the hitbox from the footbox center, reaching out 45px
            reach = 45
            hitbox = pygame.Rect(0, 0, 50, 50)
            hitbox.center = (foot_rect.centerx + (last_dx * reach), 
                             foot_rect.centery + (last_dy * reach))
            
            target_rock = next((r for r in rocks if hitbox.colliderect(r["rect"])), None)
            target_weed = next((w for w in weeds if hitbox.colliderect(w["rect"])), None)
            target_water = next((wt for wt in water_tiles if hitbox.colliderect(wt["rect"])), None)

            if target_rock and has_hammer:
                rocks.remove(target_rock)
                if target_rock["id"] == rock_key_id and not rock_key_claimed:
                    keys_found += 1; rock_key_claimed = True
                    spawn_text("KEY FOUND!", player_rect.topleft, (255, 215, 0), -45)

            elif target_weed and has_scythe:
                weeds.remove(target_weed)
                if target_weed["id"] == weed_key_id and not weed_key_claimed:
                    keys_found += 1; weed_key_claimed = True
                    spawn_text("KEY FOUND!", player_rect.topleft, (255, 215, 0), -45)

            elif target_water and has_pole:
                spawn_text("Fishing...", hitbox.topleft, (255,255,255), 10)
                if target_water["id"] == water_key_id and not water_key_claimed:
                    keys_found += 1; water_key_claimed = True
                    spawn_text("KEY FOUND!", player_rect.topleft, (255, 215, 0), -45)

        # RENDERING
        for wat in water_tiles: screen.blit(img_water_tex, wat["rect"])
        for w in weeds: screen.blit(img_weed, w["rect"])
        for r in rocks: screen.blit(img_rock, r["draw_pos"])
        for t, rt in items_on_ground.items():
            screen.blit(img_ham if t=="hammer" else img_scy if t=="scythe" else img_pole, rt)
        
        screen.blit(player_sprites[current_facing], player_rect.topleft)
        
        # UI & Victory logic
        t_surf = title_font.render("Level 4: Rengaw Valley", True, (0,0,0))
        box_width = max(350, t_surf.get_width() + 40)
        header_rect = pygame.Rect(WIDTH//2 - box_width//2, 10, box_width, 85)
        pygame.draw.rect(screen, (255, 255, 255, 190), header_rect, border_radius=15)
        screen.blit(t_surf, t_surf.get_rect(center=(WIDTH//2, 35)))
        
        d_surf = desc_font.render(f"Find the three keys ({keys_found}/3)", True, (50, 50, 50))
        screen.blit(d_surf, d_surf.get_rect(center=(WIDTH//2, 65)))

        if keys_found >= 3:
            if not level_cleared:
                level_cleared = True
                for _ in range(150):
                    confetti_particles.append({
                        "pos": [random.randint(0, WIDTH), -20],
                        "vel": [random.uniform(-2, 2), random.uniform(2, 7)],
                        "color": (random.randint(50, 255), random.randint(50, 255), random.randint(50, 255)),
                        "size": random.randint(5, 12)
                    })
                try: victory_sparkle.play()
                except: pass
            
            clue_surf = title_font.render("Now that I have the keys I can finally make my favorite mustard ice cream", True, (255, 255, 0))
            screen.blit(clue_surf, clue_surf.get_rect(center=(WIDTH//2, HEIGHT-140)))

        for ft in floating_texts[:]:
            screen.blit(font.render(ft["txt"], True, ft["color"]), ft["pos"])
            ft["pos"][1]-=1.2; ft["timer"]-=1
            if ft["timer"]<=0: floating_texts.remove(ft)

        for p in confetti_particles[:]:
            p["pos"][0] += p["vel"][0]; p["pos"][1] += p["vel"][1]; p["vel"][1] += 0.1
            pygame.draw.rect(screen, p["color"], (p["pos"][0], p["pos"][1], p["size"], p["size"]))
            if p["pos"][1] > HEIGHT:
                if level_cleared: p["pos"][1] = -10
                else: confetti_particles.remove(p)

        ui_surface.fill((0,0,0,0))
        for n, r in ctrls.items():
            pygame.draw.rect(ui_surface, (120, 120, 120, 130), r, border_radius=12)
            if n == "action": 
                txt = font.render("USE TOOL", True, (255,255,255))
                ui_surface.blit(txt, txt.get_rect(center=r.center))
            else: draw_arrow(ui_surface, r, n)
        screen.blit(ui_surface, (0,0))

        pygame.display.flip()
        await asyncio.sleep(0)
        clock.tick(60)

if __name__ == "__main__":
    asyncio.run(main())