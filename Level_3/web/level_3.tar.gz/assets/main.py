import pygame
import asyncio
import random

# --- 1. INITIALIZATION ---
pygame.init()
pygame.mixer.pre_init(44100, -16, 2, 512) 
pygame.mixer.init() 

WIDTH, HEIGHT = 800, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Level 3: Untitled Rengaw Game")
clock = pygame.time.Clock()

# Fonts
font = pygame.font.SysFont("Arial", 22, bold=True)
title_font = pygame.font.SysFont("Courier New", 32, bold=True)
desc_font = pygame.font.SysFont("Arial", 18, italic=True)

# --- 2. MUSIC & SOUND SECTION ---
try:
    pygame.mixer.music.load("Goose.ogg") 
    pygame.mixer.music.set_volume(0.2) 
    pygame.mixer.music.play(-1) 
    
    victory_sound = pygame.mixer.Sound("Honk.ogg") 
    honk_sound = pygame.mixer.Sound("Honk.ogg")
except Exception as e:
    print(f"Audio Error: {e}")
    victory_sound = pygame.mixer.Sound(buffer=bytes(100))
    honk_sound = pygame.mixer.Sound(buffer=bytes(100))

# --- 3. GLOBAL STATE ---
ui_surface = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
player_rect = pygame.Rect(100, 150, 40, 20) 
floating_texts = []
PLAYER_SPEED = 5
wobble_angle = 0
wobble_dir = 1
current_facing = "down"
screen_shake = 0 

# Level Objects
rocks, weeds = [], []
water_rect = pygame.Rect(500, 280, 180, 180)
tasks_l3 = {}
victory_sound_played = False
gardener_running = False
key_dropped = False 

# --- 4. ASSETS ---
def load_img(name, color, size):
    try: 
        return pygame.transform.scale(pygame.image.load(name).convert_alpha(), size)
    except: 
        s = pygame.Surface(size, pygame.SRCALPHA)
        s.fill(color)
        return s

G_SIZE, C_SIZE, GAR_SIZE = 90, 60, 85

goose_sprites = {
    "up":    load_img("Goose_up.png", (255, 255, 255), (G_SIZE, G_SIZE)),
    "down":  load_img("Goose_down.png", (240, 240, 240), (G_SIZE, G_SIZE)),
    "left":  load_img("Goose_left.png", (220, 220, 220), (G_SIZE, G_SIZE)),
    "right": load_img("Goose_right.png", (200, 200, 200), (G_SIZE, G_SIZE))
}

img_grass = load_img("Grass.png", (70, 140, 70), (100, 100))
img_key = load_img("Key.png", (139, 69, 19), (45, 45))
img_gardener = load_img("Gardener.png", (34, 139, 34), (GAR_SIZE, GAR_SIZE))
img_cat = load_img("Cat.png", (255, 165, 0), (C_SIZE, C_SIZE))
img_rock = load_img("Rock.png", (90, 90, 90), (55, 55))
img_weed = load_img("Weed.png", (20, 80, 20), (40, 40))

# --- 5. HELPERS ---
def draw_arrow(surface, rect, direction):
    center, s = rect.center, 15
    if direction == "up": pts = [(center[0], center[1]-s), (center[0]-s, center[1]+s), (center[0]+s, center[1]+s)]
    elif direction == "down": pts = [(center[0], center[1]+s), (center[0]-s, center[1]-s), (center[0]+s, center[1]-s)]
    elif direction == "left": pts = [(center[0]-s, center[1]), (center[0]+s, center[1]-s), (center[0]+s, center[1]+s)]
    elif direction == "right": pts = [(center[0]+s, center[1]), (center[0]-s, center[1]-s), (center[0]-s, center[1]+s)]
    pygame.draw.polygon(surface, (255,255,255), pts)

def init_level():
    global tasks_l3, rocks, weeds, player_rect, victory_sound_played, gardener_running, key_dropped
    player_rect.topleft = (100, 180)
    victory_sound_played = False
    gardener_running = False
    key_dropped = False
    tasks_l3 = {
        "key": {"rect": pygame.Rect(0, 0, 45, 45), "done": False}, 
        "gardener": {"rect": pygame.Rect(80, 460, GAR_SIZE, GAR_SIZE), "done": False}, 
        "cat": {"rect": pygame.Rect(450, 350, C_SIZE, C_SIZE), "done": False, "sliding": False, "target_pos": [450, 350]}
    }
    rocks[:] = [pygame.Rect(300, 100, 55, 55), pygame.Rect(355, 100, 55, 55),
                pygame.Rect(200, 400, 55, 55), pygame.Rect(400, 500, 55, 55),
                pygame.Rect(550, 150, 55, 55), pygame.Rect(50, 300, 55, 55)]
    weeds[:] = []
    while len(weeds) < 12:
        nw = pygame.Rect(random.randint(50, 750), random.randint(120, 550), 40, 40)
        if not nw.colliderect(water_rect): weeds.append(nw)

init_level()

bs = 75
ctrls = {"up": pygame.Rect(120, 380, bs, bs), "down": pygame.Rect(120, 500, bs, bs), 
         "left": pygame.Rect(40, 440, bs, bs), "right": pygame.Rect(200, 440, bs, bs), 
         "action": pygame.Rect(680, 20, 100, 50)}

# --- 6. MAIN LOOP ---
async def main():
    global wobble_angle, wobble_dir, current_facing, victory_sound_played, gardener_running, key_dropped, screen_shake
    honking = False
    
    while True:
        dx, dy = 0, 0
        clue = None
        m_pos, m_down = pygame.mouse.get_pos(), pygame.mouse.get_pressed()[0]
        
        offset_x = random.randint(-screen_shake, screen_shake) if screen_shake > 0 else 0
        offset_y = random.randint(-screen_shake, screen_shake) if screen_shake > 0 else 0
        if screen_shake > 0: screen_shake -= 1

        for x in range(-100, WIDTH + 100, 100):
            for y in range(-100, HEIGHT + 100, 100): 
                screen.blit(img_grass, (x + offset_x, y + offset_y))

        for event in pygame.event.get():
            if event.type == pygame.QUIT: return
            if event.type == pygame.MOUSEBUTTONDOWN and ctrls["action"].collidepoint(event.pos):
                honking = True
                honk_sound.set_volume(1.0) 
                honk_sound.play() 
                screen_shake = 5 
            if event.type == pygame.MOUSEBUTTONUP: honking = False

        if m_down:
            if ctrls["up"].collidepoint(m_pos): dy = -PLAYER_SPEED; current_facing = "up"
            elif ctrls["down"].collidepoint(m_pos): dy = PLAYER_SPEED; current_facing = "down"
            elif ctrls["left"].collidepoint(m_pos): dx = -PLAYER_SPEED; current_facing = "left"
            elif ctrls["right"].collidepoint(m_pos): dx = PLAYER_SPEED; current_facing = "right"

        if dx != 0 or dy != 0:
            wobble_angle += 10 * wobble_dir
            if abs(wobble_angle) > 15: wobble_dir *= -1
            new_x, new_y = player_rect.move(dx, 0), player_rect.move(0, dy)
            if 0 <= new_x.left and new_x.right <= WIDTH and not any(new_x.colliderect(r) for r in rocks): player_rect.x += dx
            if 100 <= new_y.top and new_y.bottom <= HEIGHT and not any(new_y.colliderect(r) for r in rocks): player_rect.y += dy
        else: wobble_angle = 0

        # --- RENDERING ---
        pygame.draw.rect(screen, (40, 120, 230), water_rect.move(offset_x, offset_y), border_radius=25)
        for w in weeds: screen.blit(img_weed, w.move(offset_x, offset_y))
        for r in rocks: screen.blit(img_rock, r.move(offset_x, offset_y))
        
        if not tasks_l3["gardener"]["done"]:
            screen.blit(img_gardener, tasks_l3["gardener"]["rect"].move(offset_x, offset_y))
            if honking and pygame.Vector2(player_rect.center).distance_to(tasks_l3["gardener"]["rect"].center) < 120:
                tasks_l3["gardener"]["done"], gardener_running, key_dropped = True, True, True
                tasks_l3["key"]["rect"].topleft = tasks_l3["gardener"]["rect"].center
                floating_texts.append({"txt":"HONK!!!", "pos":list(tasks_l3["gardener"]["rect"].topleft), "timer":70, "color":(255,255,255)})
        elif gardener_running:
            tasks_l3["gardener"]["rect"].x -= 8
            screen.blit(img_gardener, tasks_l3["gardener"]["rect"].move(offset_x, offset_y))
            screen.blit(font.render("HELP!", True, (255,0,0)), (tasks_l3["gardener"]["rect"].x + offset_x, tasks_l3["gardener"]["rect"].y - 30 + offset_y))
            if tasks_l3["gardener"]["rect"].right < 0: gardener_running = False

        if key_dropped and not tasks_l3["key"]["done"]:
            screen.blit(img_key, tasks_l3["key"]["rect"].move(offset_x, offset_y))
            if player_rect.colliderect(tasks_l3["key"]["rect"]): 
                tasks_l3["key"]["done"] = True
                floating_texts.append({"txt":"My Precious", "pos":list(player_rect.topleft), "timer":60, "color":(255,255,0)})

        cat = tasks_l3["cat"]
        if not cat["done"]:
            if player_rect.colliderect(cat["rect"]) and not cat["sliding"]:
                p_dir = [80,0] if dx>0 else [-80,0] if dx<0 else [0,80] if dy>0 else [0,-80]
                if p_dir != [0,0]: cat["target_pos"], cat["sliding"] = [cat["rect"].x+p_dir[0], cat["rect"].y+p_dir[1]], True
            if cat["sliding"]:
                s = 8
                if abs(cat["rect"].x-cat["target_pos"][0]) > s: cat["rect"].x += s if cat["rect"].x < cat["target_pos"][0] else -s
                if abs(cat["rect"].y-cat["target_pos"][1]) > s: cat["rect"].y += s if cat["rect"].y < cat["target_pos"][1] else -s
                if abs(cat["rect"].x-cat["target_pos"][0]) <= s and abs(cat["rect"].y-cat["target_pos"][1]) <= s:
                    cat["rect"].topleft, cat["sliding"] = cat["target_pos"], False
                    if cat["rect"].colliderect(water_rect): 
                        cat["done"] = True
                        floating_texts.append({"txt":"SPLASH!", "pos":list(cat["rect"].center), "timer":80, "color":(0,200,255)})
            screen.blit(img_cat, cat["rect"].move(offset_x, offset_y))

        # Task List UI
        paper = pygame.Rect(20, 110, 200, 110)
        pygame.draw.rect(screen, (255, 255, 240), paper); pygame.draw.rect(screen, (100, 100, 80), paper, 2)
        screen.blit(font.render("To-Do:", True, (50, 50, 120)), (30, 115))
        td_items = [("Scare the Gardener", "gardener"), ("Steal the Key", "key"), ("Give Cat a Bath", "cat")]
        done_count = sum(t["done"] for t in tasks_l3.values())
        for i, (name, key) in enumerate(td_items):
            is_done = tasks_l3[key]["done"]
            col = (180, 180, 180) if is_done else (30, 30, 30)
            screen.blit(font.render(f"- {name}", True, col), (35, 140 + (i * 22)))
            if is_done: pygame.draw.line(screen, (200, 0, 0), (35, 152 + (i * 22)), (185, 152 + (i * 22)), 2)

        # --- DYNAMIC HEADERS ---
        title_str = "Level 3: Untitled Rengaw Game"
        t_surf = title_font.render(title_str, True, (0,0,0))
        
        # Calculate box size based on title width
        box_width = t_surf.get_width() + 40
        header_rect = pygame.Rect(WIDTH//2 - box_width//2, 10, box_width, 80)
        
        pygame.draw.rect(screen, (255, 255, 255, 180), header_rect, border_radius=15)
        screen.blit(t_surf, t_surf.get_rect(center=(WIDTH//2, 35)))
        
        d_surf = desc_font.render(f"Complete the tasks! ({done_count}/3)", True, (50,50,50))
        screen.blit(d_surf, d_surf.get_rect(center=(WIDTH//2, 60)))
        
        # Goose Rendering
        waddle = pygame.transform.rotate(goose_sprites[current_facing], wobble_angle)
        screen.blit(waddle, waddle.get_rect(centerx=player_rect.centerx + offset_x, bottom=player_rect.bottom + 10 + offset_y).topleft)
        if honking: screen.blit(font.render("HONK!", True, (255,255,255)), (player_rect.x-10 + offset_x, player_rect.y-60 + offset_y))

        for ft in floating_texts[:]:
            screen.blit(font.render(ft["txt"], True, ft["color"]), (ft["pos"][0] + offset_x, ft["pos"][1] + offset_y))
            ft["pos"][1]-=1; ft["timer"]-=1
            if ft["timer"]<=0: floating_texts.remove(ft)

        ui_surface.fill((0,0,0,0))
        for n, r in ctrls.items():
            pygame.draw.rect(ui_surface, (120, 120, 120, 100), r, border_radius=12)
            if n == "action": ui_surface.blit(font.render("HONK", True, (255,255,255)), font.render("HONK", True, (255,255,255)).get_rect(center=r.center))
            else: draw_arrow(ui_surface, r, n)
        screen.blit(ui_surface, (0,0))

        if done_count == 3:
            clue = "Honk Honk! I keep secrets with my potential offspring"
            txt = title_font.render(clue, True, (255, 255, 0))
            pygame.draw.rect(screen, (0,0,0,150), txt.get_rect(center=(WIDTH//2, HEIGHT-60)).inflate(20, 10), border_radius=10)
            screen.blit(txt, txt.get_rect(center=(WIDTH//2, HEIGHT-60)))
            if not victory_sound_played: victory_sound.play(); victory_sound_played = True

        pygame.display.flip(); await asyncio.sleep(0); clock.tick(60)

if __name__ == "__main__": asyncio.run(main())